<div class="list">
    <ul>
        <li>list 1
            <ul>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </li>
        <li>list 2
            <ul>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </li>
        <li>list 3
            <ul>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </li>
        <li>list 4
            <ul>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </li>
    </ul>
</div>