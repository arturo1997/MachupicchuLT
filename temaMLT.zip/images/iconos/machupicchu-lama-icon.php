<svg xmlns="http://www.w3.org/2000/svg" width="63" height="53" viewBox="0 0 63 53" fill="none">
    <g clip-path="url(#clip0_166_29)">
        <path class="color-1"
            d="M58.73 4.44V0H54.3V4.44V8.87V16.27H46.9H45.79H42.47V20.33H38.4V24.77H42.47V36.6H46.9V28.47H54.3V36.6H58.73V8.87H62.8V4.44H58.73Z"
            fill="#F6BE46" />
        <path class="color-1"
            d="M20.33 16.27H17.01H15.9H8.5V0H4.07V4.44H0V8.87H4.07V20.33V24.77V36.6H8.5V28.47H15.9V36.6H20.33V24.77H24.4V20.33H20.33V16.27Z"
            fill="#F6BE46" />
        <path class="color-2" d="M62.4 40H41.71L31.71 30L21.71 40H0.400024V43H22.09L31.71 52.63L41.34 43H62.4V40Z"
            fill="#8F2A1A" />
    </g>
    <defs>
        <clipPath id="clip0_166_29">
            <rect width="62.8" height="52.63" fill="white" />
        </clipPath>
    </defs>
</svg>