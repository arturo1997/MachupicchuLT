<section class=" p-top-bottom">
    <div class="premios-asociaciones">
        <div class="premios-asociaciones-item">
            <img class="" src="<?php echo get_template_directory_uri(); ?>/images/machupicchu-lama-tripadvisor.png"
                alt="" />
        </div>
        <div class="premios-asociaciones-item">
            <img class="" src="<?php echo get_template_directory_uri(); ?>/images/machupicchu-lama-airbnb.png" alt="" />
        </div>
        <div class="premios-asociaciones-item">
            <img class="" src="<?php echo get_template_directory_uri(); ?>/images/machupicchu-lama-protegeme.png"
                alt="" />
        </div>
    </div>
    <div class="organizaciones">
        <div class="premios-organizaciones-item">
            <img class="" src="<?php echo get_template_directory_uri(); ?>/images/machupicchu-lama-peru.png" alt="" />
        </div>
        <div class="premios-organizaciones-item">
            <img class="" src="<?php echo get_template_directory_uri(); ?>/images/machupicchu-lama-mincetur.png"
                alt="" />
        </div>
        <div class="premios-organizaciones-item">
            <img class="" src="<?php echo get_template_directory_uri(); ?>/images/machupicchu-lama-dircetur.png"
                alt="" />
        </div>
    </div>
</section>